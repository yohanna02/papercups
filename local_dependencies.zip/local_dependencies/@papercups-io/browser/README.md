# @papercups-io/browser

> Papercups browser JS/TS library

[![NPM](https://img.shields.io/npm/v/@papercups-io/browser.svg)](https://www.npmjs.com/package/@papercups-io/browser)

## Install

```bash
npm install --save @papercups-io/browser
```
